const mongoose=require("mongoose");
const sch=mongoose.Schema({
    email:String,
    product_prize:String,
    product_name:String,
    product_image:String
});

module.exports=mongoose.model("Payemnt_CODs",sch);