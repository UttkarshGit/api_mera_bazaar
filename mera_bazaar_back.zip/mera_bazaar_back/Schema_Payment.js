const mongoose=require("mongoose");
const data=mongoose.Schema({
    email:String,
    product_prize:String,
    product_name:String,
    upi_id:String,
    product_image:String
})

module.exports=mongoose.model("User_payments",data);