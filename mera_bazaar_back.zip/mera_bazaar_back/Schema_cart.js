const mongoose=require("mongoose");
const data=mongoose.Schema({
    image:String,
    product_name:String,
    prize:String,
    user_login:String

})

module.exports=mongoose.model('cart_items',data);