const mongoose=require("mongoose");
const data=mongoose.Schema({
    count:String
})

module.exports=mongoose.model("login_counts",data);