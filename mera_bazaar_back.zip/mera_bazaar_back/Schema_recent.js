const mongoose=require("mongoose");
const data=mongoose.Schema({
    product_name:String,
    product_prize:String,
    email:String,
    product_image:String
})

module.exports=mongoose.model("recent_views",data);