const mongoose=require("mongoose");
const data=mongoose.Schema({
  email:String,
  image_name:String,
  prize:String,
  color:String
})

module.exports=mongoose.model("upload_images",data);