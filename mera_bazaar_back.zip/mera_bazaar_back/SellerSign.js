const mongoose=require("mongoose");
const sch=mongoose.Schema({
    name:String,
    email:String,
    password:String,
    aadhaar:String,
    panno:String
});

module.exports=mongoose.model("seller_signups",sch);