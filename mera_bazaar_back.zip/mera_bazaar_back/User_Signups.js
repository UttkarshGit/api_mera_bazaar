const mongoose=require("mongoose");
const sch=mongoose.Schema({
    name:String,
    email:String,
    password:String
});

module.exports=mongoose.model("User_Signups",sch);