require("./Connection");
const express=require('express');

const Schema_cart=require('./Schema_cart');
const app=express();


const bodyParser=require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:false}))
const multer=require('multer');
const upload=multer({dest:'C:/Users/hp/Desktop/fi_mart/Front/cart/public/uploads/'})



const User_Signups=require('./User_Signups');
const User_payment=require('./Schema_Payment');
const Schema_credit=require("./Schema_creditpayment");
const adminn=require("./Schema_admin");
const cod=require('./Schema_Cash');
const cors=require('cors');
const upload_image=require('./Schema_uploadimage');
const Schema_res=require("./Schema_recent");
const Schema_Cash = require("./Schema_Cash");
const Schema_creditpayment = require("./Schema_creditpayment");
const Schema_Payment = require("./Schema_Payment");
const Schema_recent = require("./Schema_recent");
const Schema_uploadimage = require("./Schema_uploadimage");
const count=require('./Schema_count');
const Schema_count = require("./Schema_count");
const seller_signups=require('./SellerSign');

app.use(express.json());
app.use(cors());

app.get('/get_data',async (req,res)=>{
    const val=await Schema_cart.find({});
    res.send(val);
})

app.post('/send_data',async(req,res)=>{
    const s_data=new Schema_cart(req.body);
    const send_value= await s_data.save();
    res.send(req.body);
})

app.post("/remove",async(req,res)=>{
    const all_data=await Schema_cart.deleteOne(req.body);
    res.send("deleted");
})

app.post('/register',async (req,res)=>{
    const submit=new User_Signups(req.body);
    let  val=await submit.save();
    res.send(req.body);
})

app.post('/login',async (req,res)=>{
    if(req.body.email && req.body.password)
    {
        let val=await User_Signups.findOne(req.body);
        if(val)
        {
            res.send(val);
        }
        else{
            res.send({rest:"no user exist"});
        }
    }
    else
    {
        res.send({rest:"Not match"}); 
    }
});

app.post('/login_sign',async (req,res)=>{
    if(req.body.email!="")
    {
        let val=await User_Signups.findOne(req.body);
        if(val)
        {
            res.send(val);
        }
        else{
            res.send({rest:"no user exist"});
        }
    }
    else
    {
        res.send({rest:"Not match"}); 
    }
});

//--------------payemnt from user

app.post('/payment',async (req,res)=>{
    const alldata=new User_payment(req.body);
    const send_value= await alldata.save();
    res.send(send_value);
})


app.post('/payment_credit',async (req,res)=>{
    const alldata=new Schema_credit(req.body);
    const send_value= await alldata.save();
    res.send(send_value);
})


app.post('/payment_net',async (req,res)=>{
    const alldata=new cod(req.body);
    const send_value= await alldata.save();
    res.send(send_value);
})


//-----------payment from user get
app.post('/payment_cod_get',async (req,res)=>{
    const alldata=await cod.find(req.body);
    res.send(alldata);
})

app.post('/payment_credit_get',async (req,res)=>{
    const alldata=await Schema_credit.find(req.body);
    res.send(alldata);
})

app.post('/payment_upi_get',async (req,res)=>{
    const alldata=await User_payment.find(req.body);
    res.send(alldata);
})

app.post('/login_admin',async (req,res)=>{
    const alldata=await adminn.findOne(req.body);
    if(alldata)
        {
            res.send(alldata);
        }
        else{
            res.send({rest:"no"});
        }
})

app.post('/cancelorder_upi',async (req,res)=>{
    const alldata=await User_payment.deleteOne(req.body);
    if(alldata)
    {
        res.send(alldata);
    }
    else
    {
        res.send({rest:"no"});
    }
})

app.post('/cancelorder_credit',async (req,res)=>{
    const alldata=await Schema_credit.deleteOne(req.body);
    if(alldata)
    {
        res.send(alldata);
    }
    else
    {
        res.send({rest:"no"});
    }
})

app.post('/cancelorder_cod',async (req,res)=>{
    const alldata=await cod.deleteOne(req.body);
    if(alldata)
    {
        res.send(alldata);
    }
    else
    {
        res.send({rest:"no"});
    }
})

let file_name="";
app.post('/api/image',upload.single('image'),async (req,res)=>{
    if(!req.file)
    {
        res.send({code:500,msg:"error"});
    }
    else
    {
        file_name=req.file.filename;
        res.send("done");
    }
})
    app.post("/api/upload_image",async(req,res)=>{
        let values={
            "email":req.body.email,
            "image_name":file_name,
            "prize":req.body.prize,
            "color":req.body.color
        }
        const data=new upload_image(values)
        const send_value= await data.save();
        console.log(send_value);
    })

app.post('/up_image',async (req,res)=>{
        const alldata=await upload_image.find(req.body);
        res.send(alldata);
})

app.post("/recent",async(req,res)=>{
    const data=await Schema_res.find(req.body);
    let di=data+"";
    if(di.length==0)
    {
        res.send({"ch":"not found"})
    }
    else{
        res.send({"ch":"find"})
    }
})

app.post("/recent_send",async(req,res)=>{
    const val=new Schema_res(req.body);
    const finn=await val.save();
})

app.post("/recent_update",async(req,res)=>{
    const val=await Schema_res.updateMany({"email":req.body.email},{$set:req.body});

})

app.get("/signup_all_data",async(req,res)=>{
    const data= await User_Signups.find({});
    res.send(data);
})

app.get("/cart_all_data",async(req,res)=>{
    const data= await Schema_cart.find({});
    res.send(data);
})

app.get("/cash_all_data",async(req,res)=>{
    const data= await Schema_Cash.find({});
    res.send(data);
})

app.get("/credit_all_data",async(req,res)=>{
    const data= await Schema_creditpayment.find({});
    res.send(data);
})

app.get("/upi_all_data",async(req,res)=>{
    const data= await Schema_Payment.find({});
    res.send(data);
})

app.get("/active_all_data",async(req,res)=>{
    const data= await Schema_recent.find({});
    res.send(data);
})

app.get("/upload_all_data",async(req,res)=>{
    const data= await Schema_uploadimage.find({});
    res.send(data);
})


app.post("/logged_in_user",async(req,res)=>{
    const data= new Schema_count(req.body);
    const tot=await data.save();
    res.send(tot);
})

app.get("/loggs",async(req,res)=>{
    const data= await Schema_count.find({});
    res.send(data);
})

app.post("/del",async(req,res)=>{
    const deldata=await Schema_count.deleteOne(req.body);
})

//-------------------Seller SignUp

app.post('/seller_register',async (req,res)=>{
    const submit=new seller_signups(req.body);
    let  val=await submit.save();
    res.send(req.body);
})

app.post('/seller_login',async (req,res)=>{
    if(req.body.email!="")
    {
        let val=await seller_signups.findOne(req.body);
        if(val)
        {
            res.send(val);
        }
        else{
            res.send({rest:"no user exist"});
        }
    }
    else
    {
        res.send({rest:"Not match"}); 
    }
});



app.get('/all_image',async (req,res)=>{
    const alldata=await upload_image.find({});
    res.send(alldata);
})


app.listen(4000);